library(testthat)
library(splitr)

test_check("splitr")
